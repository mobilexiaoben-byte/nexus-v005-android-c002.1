# V005-C002-AUTH-FLOW-INSTRUMENTATION-001

Status: CANDIDATE / NON_CANONICAL / DEVICE TEST REQUIRED.

Purpose: diagnose the ChatGPT authentication redirect in Android System WebView without collecting credentials.

Instrumentation records only:
- main-frame navigation start/finish;
- sanitized scheme + host + path (query, fragment and user-info removed);
- allow/block decision for top-level navigation;
- main-frame WebView error code;
- main-frame HTTP status code;
- SSL primary error code;
- coarse ChatGPT auth state (AUTHENTICATED / UNAUTHENTICATED / UNKNOWN).

Explicitly not recorded:
- query strings or fragments;
- passwords;
- cookies;
- OAuth authorization codes;
- tokens;
- request/response headers;
- request/response bodies;
- form contents.

The bridge injection allowlist is unchanged and remains limited to `https://chatgpt.com` for ChatGPT. The navigation allowlist is not broadened in this build: any newly required authentication host will be visible as a sanitized `NAV_REQUEST ... BLOCK` event and must be reviewed before any minimal allowlist change.

Gate: build APK, install on Android real device, attempt ChatGPT authentication, then stop on the first failure or on `DESCRIBE PASS — STOP GATE`. No provider job is authorized.
