# GitHub Actions build — V005 C002 AUTHDIAG001

The source package contains `.github/workflows/build-apk.yml`.

Expected artifact after a PASS build:
- `NEXUS-V005-C002-AUTHDIAG001-debug.apk`
- SHA record from the workflow

Device gate after build:
1. If Android refuses an in-place update because the previous debug APK used a different ephemeral debug certificate, uninstall the old debug build first. This clears the isolated WebView profile, so authenticate again in the instrumented build.
2. Install and launch the AUTHDIAG001 APK.
3. Attempt ChatGPT authentication once.
4. Read/copy the `AUTH FLOW — SANITIZED` panel. It contains no query, fragment, user-info, cookie, token, header or form content.
5. Stop immediately on the first `BLOCKED` event or on `DESCRIBE PASS — STOP GATE`.
6. Do not initiate any provider execution job.
