# NEXUS V-005 — Android Chromium/WebView C002

Sandbox candidate implementing the V-005 C002 Android container.

## Runtime shape
Kotlin Android app → Android System WebView (Chromium) → Jetpack WebKit 1.17.0 → isolated WebView profile → isolated JS world → origin-restricted NexusWebBridge → statically ported V-001 provider adapters.

## Toolchain target
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- JDK 17+
- compileSdk / targetSdk 36
- minSdk 24
- androidx.webkit 1.17.0

## Validation available in this package
- `./run_core_tests.sh` — pure Kotlin fail-closed/correlation suite.
- `./run_validation.sh` — static container + JS syntax + core suite.
- `VALIDATION_REPORT.md` — exact proven/not-proven boundary.
- `PROVIDER_ADAPTER_SHA256.txt` — V-001 source and C002 port hashes.

Full Android build and instrumented WebView tests require Android SDK plus a compatible WebView runtime/device.

## Runtime proof update
`V005-C002-ANDROID-RUNTIME-PROOF-001` is now DESCRIBE-only. After ChatGPT authentication the native layer converts `CHATGPT_STATUS` into `NEXUS_ANDROID_DESCRIBE_C002`, validates it, and displays `DESCRIBE PASS — STOP GATE`. No provider execution job is sent in this gate.

Local result: 25/25 core + 10/10 static checks PASS. APK/device proof remains pending because this execution environment has no Android SDK/WebView runtime/device.

## GitHub browser build path
The candidate now contains `.github/workflows/build-apk.yml`. From an Android browser, a GitHub repository can run this workflow manually and publish `NEXUS-V005-C002-debug.apk` as a direct Actions artifact. See `GITHUB_ANDROID_BUILD.md`.
