# Provider adapter C002 port notes

Source: V-001 candidate 001 provider adapters.

Port rule:
- DOM/auth/prompt/result logic preserved.
- `chrome.runtime.sendMessage` -> `nativeSend` -> `NexusNativeC002.postMessage`.
- `chrome.runtime.onMessage.addListener` -> `nativeOnMessage` -> `NexusNativeC002` message event.
- provider acceptance ACK is surfaced as `PROVIDER_ACK` to native.
- no `addJavascriptInterface`.
- scripts execute only in the isolated `nexus_bridge_c002` JavaScript world and only on their exact provider origin.

This is a static port. Real WebView DOM/auth behavior still requires Android runtime proof.
