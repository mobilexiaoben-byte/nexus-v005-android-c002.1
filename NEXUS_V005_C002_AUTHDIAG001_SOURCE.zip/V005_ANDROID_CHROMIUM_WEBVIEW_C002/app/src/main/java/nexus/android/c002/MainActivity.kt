package nexus.android.c002

import android.app.Activity
import android.net.http.SslError
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.View
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import nexus.android.c002.core.AuthFlowSanitizer
import nexus.android.c002.core.BridgeDescriptor
import nexus.android.c002.core.RuntimeGate
import nexus.android.c002.web.NexusWebBridge
import nexus.android.c002.web.OriginPolicy
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private lateinit var diagnostics: TextView
    private var bridge: NexusWebBridge? = null
    private var describePassed = false
    private val authEvents = ArrayDeque<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.providerWebView)
        status = findViewById(R.id.status)
        diagnostics = findViewById(R.id.diagnostics)
        diagnostics.movementMethod = ScrollingMovementMethod.getInstance()
        recordAuthEvent("DIAGNOSTICS_START", CHATGPT_ORIGIN, "query_fragment_userinfo=REDACTED")

        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            block("ANDROID_WEBKIT_FEATURE_MISSING:MULTI_PROFILE")
            return
        }
        WebViewCompat.setProfile(webView, PROFILE_NAME)

        hardenWebView(webView)
        val chatGptAdapter = assets.open("nexus/chatgpt_provider_c002.js").bufferedReader().use { it.readText() }
        val claudeAdapter = assets.open("nexus/claude_provider_c002.js").bufferedReader().use { it.readText() }
        bridge = NexusWebBridge(webView, ::handleBridgeMessage)
        val install = bridge!!.install(chatGptAdapter, claudeAdapter)
        if (!install.pass) {
            block(install.code)
            return
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                val rawUrl = request.url.toString()
                val allowed = OriginPolicy.isTopLevelNavigationAllowed(rawUrl)
                recordAuthEvent("NAV_REQUEST", rawUrl, if (allowed) "ALLOW" else "BLOCK")
                return if (allowed) {
                    false
                } else {
                    block("ANDROID_NAVIGATION_ORIGIN_BLOCKED:${AuthFlowSanitizer.host(rawUrl)}")
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                describePassed = false
                bridge?.clearForNavigation()
                val safe = AuthFlowSanitizer.sanitizeLocation(url)
                recordAuthEvent("PAGE_STARTED", url)
                status.text = "DESCRIBE pending — loading $safe"
            }

            override fun onPageFinished(view: WebView, url: String) {
                recordAuthEvent("PAGE_FINISHED", url)
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (!request.isForMainFrame) return
                recordAuthEvent("MAIN_FRAME_ERROR", request.url.toString(), "code=${error.errorCode}")
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                if (!request.isForMainFrame) return
                recordAuthEvent("MAIN_FRAME_HTTP", request.url.toString(), "status=${errorResponse.statusCode}")
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                recordAuthEvent("SSL_ERROR", error.url, "primary=${error.primaryError}")
                handler.cancel()
                block("ANDROID_SSL_ERROR:${error.primaryError}")
            }
        }

        status.text = "C002 auth-instrumented DESCRIBE-only runtime — authenticate in ChatGPT; no LLM job will be dispatched"
        webView.loadUrl(CHATGPT_ORIGIN + "/")
    }

    private fun handleBridgeMessage(origin: String, payload: String) {
        if (describePassed) return
        val message = runCatching { JSONObject(payload) }.getOrElse {
            block("ANDROID_DESCRIBE_MESSAGE_MALFORMED")
            return
        }
        if (message.optString("type") != "CHATGPT_STATUS") return
        if (message.optString("channel") != CHATGPT_CHANNEL) {
            block("ANDROID_DESCRIBE_CHANNEL_MISMATCH")
            return
        }
        val auth = message.optJSONObject("status") ?: run {
            block("ANDROID_DESCRIBE_STATUS_MISSING")
            return
        }
        val authState = auth.optString("state", "UNKNOWN")
        recordAuthEvent("AUTH_STATE", origin, authState)
        val descriptor = BridgeDescriptor(
            authenticated = authState == "AUTHENTICATED",
            origin = origin,
            targetCount = 1,
            adapterReady = true,
            missingFeatures = emptySet()
        )
        val gate = RuntimeGate.validateDescriptor(descriptor, CHATGPT_ORIGIN)
        val out = JSONObject()
            .put("contract", "NEXUS_ANDROID_DESCRIBE_C002")
            .put("provider_family", "OPENAI")
            .put("adapter_id", "ADP-OPENAI-FAMILY")
            .put("origin", origin)
            .put("authenticated", descriptor.authenticated)
            .put("auth_state", authState)
            .put("target_count", descriptor.targetCount)
            .put("adapter_ready", descriptor.adapterReady)
            .put("model_ref", "ChatGPT UI session — exact backend model not exposed by bridge")
            .put("external_research", false)
            .put("canonical_write", false)
            .put("state_mutation_mode", "NONE")
            .put("truth_winner", "NONE")
            .put("gate", gate.code)

        if (!gate.pass) {
            if (gate.code == "ANDROID_AUTH_REQUIRED") {
                status.text = "DESCRIBE BLOCKED — ANDROID_AUTH_REQUIRED\nAuthenticate in ChatGPT; retry is automatic.\n$out"
            } else {
                block("DESCRIBE_${gate.code}")
            }
            return
        }

        describePassed = true
        recordAuthEvent("DESCRIBE_PASS", origin, "authenticated=true")
        status.text = "DESCRIBE PASS — STOP GATE\n${out.toString(2)}"
        // Deliberately no provider job dispatch here. V-005 runtime proof must stop after DESCRIBE.
    }

    private fun recordAuthEvent(type: String, rawUrl: String? = null, detail: String? = null) {
        val safeLocation = AuthFlowSanitizer.sanitizeLocation(rawUrl)
        val safeDetail = detail.orEmpty().replace('\n', ' ').replace('\r', ' ').take(120)
        val line = buildString {
            append(System.currentTimeMillis())
            append(" | ").append(type)
            append(" | ").append(safeLocation)
            if (safeDetail.isNotBlank()) append(" | ").append(safeDetail)
        }
        if (authEvents.size >= MAX_AUTH_EVENTS) authEvents.removeFirst()
        authEvents.addLast(line)
        if (::diagnostics.isInitialized) {
            diagnostics.text = "AUTH FLOW — SANITIZED (no query/fragment/user-info)\n" + authEvents.joinToString("\n")
            diagnostics.post {
                val layout = diagnostics.layout ?: return@post
                val scrollAmount = layout.getLineTop(diagnostics.lineCount) - diagnostics.height
                diagnostics.scrollTo(0, scrollAmount.coerceAtLeast(0))
            }
        }
    }

    private fun hardenWebView(view: WebView) {
        with(view.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
        }
        WebView.setWebContentsDebuggingEnabled(false)
    }

    private fun block(code: String) {
        status.text = "BLOCKED — $code"
        if (::webView.isInitialized) webView.visibility = View.GONE
    }

    companion object {
        const val PROFILE_NAME = "nexus_provider_profile_c002"
        const val CHATGPT_ORIGIN = "https://chatgpt.com"
        const val CHATGPT_CHANNEL = "NEXUS_POC022_C8B2R1"
        const val MAX_AUTH_EVENTS = 60
    }
}
