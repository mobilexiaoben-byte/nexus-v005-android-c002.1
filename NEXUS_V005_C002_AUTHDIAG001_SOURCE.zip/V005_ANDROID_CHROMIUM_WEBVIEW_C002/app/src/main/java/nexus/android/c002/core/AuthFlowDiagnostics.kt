package nexus.android.c002.core

import java.net.URI

/**
 * Sanitizes provider/auth navigation locations before they are shown or logged.
 * Query, fragment, user-info and headers are deliberately excluded so OAuth
 * codes, tokens and other credentials cannot enter NEXUS diagnostics.
 */
object AuthFlowSanitizer {
    private const val MAX_PATH = 180

    fun sanitizeLocation(rawUrl: String?): String {
        if (rawUrl.isNullOrBlank()) return "<none>"
        val uri = runCatching { URI(rawUrl) }.getOrNull() ?: return "<invalid-url>"
        val scheme = uri.scheme?.lowercase() ?: return "<invalid-url>"
        val host = uri.host?.lowercase() ?: return "<no-host>"
        val port = if (uri.port >= 0) ":${uri.port}" else ""
        val rawPath = uri.rawPath.orEmpty().ifBlank { "/" }
        val path = if (rawPath.length <= MAX_PATH) rawPath else rawPath.take(MAX_PATH) + "…"
        return "$scheme://$host$port$path"
    }

    fun host(rawUrl: String?): String {
        if (rawUrl.isNullOrBlank()) return "<none>"
        return runCatching { URI(rawUrl).host?.lowercase() }.getOrNull() ?: "<no-host>"
    }
}
