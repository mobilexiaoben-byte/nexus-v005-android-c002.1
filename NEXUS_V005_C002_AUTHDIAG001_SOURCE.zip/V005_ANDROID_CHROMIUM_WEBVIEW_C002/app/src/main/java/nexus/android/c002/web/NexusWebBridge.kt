package nexus.android.c002.web

import android.webkit.WebView
import androidx.webkit.JavaScriptExecutionWorld
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class NexusWebBridge(
    private val webView: WebView,
    private val onMessage: (origin: String, payload: String) -> Unit
) {
    private val replyByOrigin = mutableMapOf<String, JavaScriptReplyProxy>()
    private var world: JavaScriptExecutionWorld? = null

    fun install(chatGptAdapterScript: String, claudeAdapterScript: String): BridgeInstallResult {
        val required = listOf(
            WebViewFeature.MULTI_PROFILE,
            WebViewFeature.WEB_MESSAGE_LISTENER,
            WebViewFeature.JS_INJECTION_IN_FRAME_AND_WORLD
        )
        val missing = required.filterNot(WebViewFeature::isFeatureSupported)
        if (missing.isNotEmpty()) return BridgeInstallResult(false, "ANDROID_WEBKIT_FEATURE_MISSING:${missing.joinToString(",")}")

        val isolatedWorld = WebViewCompat.getExecutionWorld(webView, "nexus_bridge_c002")
        world = isolatedWorld
        WebViewCompat.addWebMessageListener(
            webView,
            JS_OBJECT,
            OriginPolicy.bridgeOrigins,
            isolatedWorld
        ) { _, message, sourceOrigin, isMainFrame, replyProxy ->
            if (!isMainFrame) return@addWebMessageListener
            val origin = sourceOrigin.toString().trimEnd('/')
            if (!OriginPolicy.isBridgeOriginAllowed(origin)) return@addWebMessageListener
            replyByOrigin[origin] = replyProxy
            val data = message.data ?: return@addWebMessageListener
            onMessage(origin, data)
        }
        WebViewCompat.addJavaScriptOnEvent(
            webView,
            chatGptAdapterScript,
            WebViewCompat.INJECTION_EVENT_DOCUMENT_START,
            setOf("https://chatgpt.com"),
            isolatedWorld
        )
        WebViewCompat.addJavaScriptOnEvent(
            webView,
            claudeAdapterScript,
            WebViewCompat.INJECTION_EVENT_DOCUMENT_START,
            setOf("https://claude.ai"),
            isolatedWorld
        )
        return BridgeInstallResult(true, "PASS")
    }

    fun post(origin: String, json: String): Boolean {
        if (!OriginPolicy.isBridgeOriginAllowed(origin)) return false
        val proxy = replyByOrigin[origin] ?: return false
        proxy.postMessage(json)
        return true
    }

    fun clearForNavigation() {
        replyByOrigin.clear()
    }

    companion object {
        const val JS_OBJECT = "NexusNativeC002"
    }
}

data class BridgeInstallResult(val pass: Boolean, val code: String)
