import nexus.android.c002.core.*

private var pass = 0
private var fail = 0
private fun check(name: String, condition: Boolean) {
    if (condition) { println("PASS $name"); pass++ } else { println("FAIL $name"); fail++ }
}

fun main() {
    val sanitizedCallback = AuthFlowSanitizer.sanitizeLocation("https://user:pass@auth.openai.com/callback?code=SECRET_TOKEN#frag")
    check("AUTH01 callback query fragment userinfo redacted", sanitizedCallback == "https://auth.openai.com/callback")
    check("AUTH02 host extraction", AuthFlowSanitizer.host("https://auth.openai.com/callback?code=x") == "auth.openai.com")
    check("AUTH03 invalid url fails closed", AuthFlowSanitizer.sanitizeLocation("not a valid url") == "<invalid-url>")
    val engine = AndroidTransportEngine()
    val base = ExecutionInput("job-1", "question", "handoff", SelectedProvider.CHATGPT, "gpt-test")
    val job = engine.buildJob(base)
    check("T03 provider policy", job.providerFamily == "OPENAI" && job.adapterId == "ADP-OPENAI-FAMILY")
    check("T04 one provider", job.provider == SelectedProvider.CHATGPT)
    check("T05 external research fail closed", runCatching { engine.buildJob(base.copy(requestId="job-er", externalResearch=true)) }.isFailure)
    check("T06 frozen fingerprint", job.frozenFingerprint.length == 64 && job.frozenFingerprint == AndroidTransportEngine.sha256(job.frozenPackage.canonicalString()))
    check("T07 ACK correlated", RuntimeGate.validateAck(received=true, correlated=true).pass)

    fun receipt(
        jobId: String = job.jobId,
        packId: String = job.contextPackId,
        question: String = job.question,
        fingerprint: String = job.frozenFingerprint,
        providerFamily: String = job.providerFamily,
        modelRef: String? = job.model,
        transport: String = "ANDROID_WEBVIEW_CHROMIUM_BRIDGE",
        canonicalWrite: Boolean = false,
        stateMutation: String = "NONE",
        truthWinner: String = "NONE",
        answer: String? = "ok",
        forbidden: Set<String> = emptySet()
    ) = AndroidReceipt(
        "COMPLETED", jobId, packId, question, fingerprint,
        ProviderMetadata(providerFamily, modelRef), ExecutionReceiptMetadata(transport),
        canonicalWrite, stateMutation, truthWinner, answer, forbiddenFields = forbidden
    )

    check("T08 terminal receipt nominal", AndroidTransportEngine().validateReceipt(job, receipt()).pass)
    check("T09 provenance present", AndroidTransportEngine().validateReceipt(job, receipt()).pass)
    check("T10 job mismatch blocked", !AndroidTransportEngine().validateReceipt(job, receipt(jobId="wrong")).pass)
    check("T11 pack mismatch blocked", !AndroidTransportEngine().validateReceipt(job, receipt(packId="wrong")).pass)
    check("T12 question mismatch blocked", !AndroidTransportEngine().validateReceipt(job, receipt(question="wrong")).pass)
    check("T13 fingerprint mismatch blocked", !AndroidTransportEngine().validateReceipt(job, receipt(fingerprint="bad")).pass)
    check("T14 model mismatch blocked", !AndroidTransportEngine().validateReceipt(job, receipt(modelRef="wrong")).pass)
    val duplicateEngine = AndroidTransportEngine()
    check("T15 first execution accepted", duplicateEngine.validateReceipt(job, receipt()).pass)
    check("T15 duplicate execution blocked", !duplicateEngine.validateReceipt(job, receipt()).pass)
    check("T16 absence auth blocked", !RuntimeGate.validateDescriptor(BridgeDescriptor(false, job.origin, 1, true), job.origin).pass)
    check("T17 unexpected origin blocked", !RuntimeGate.validateDescriptor(BridgeDescriptor(true, "https://evil.example", 1, true), job.origin).pass)
    check("T18 missing WebKit feature blocked", !RuntimeGate.validateDescriptor(BridgeDescriptor(true, job.origin, 1, true, setOf("MULTI_PROFILE")), job.origin).pass)
    check("T19 ACK timeout blocked", !RuntimeGate.validateAck(received=false, correlated=false).pass)
    check("T20 terminal timeout blocked", !RuntimeGate.validateTerminal(received=false).pass)
    check("T21 canonical write blocked", !AndroidTransportEngine().validateReceipt(job, receipt(canonicalWrite=true)).pass)
    check("T22 mutation blocked", !AndroidTransportEngine().validateReceipt(job, receipt(stateMutation="WRITE")).pass)
    check("T23 truth winner blocked", !AndroidTransportEngine().validateReceipt(job, receipt(truthWinner="MODEL")).pass)
    check("T24 Gemini disabled", runCatching { engine.buildJob(base.copy(requestId="gem", provider=SelectedProvider.GEMINI)) }.isFailure)
    check("secret field blocked", !AndroidTransportEngine().validateReceipt(job, receipt(forbidden=setOf("token"))).pass)
    check("adapter pending fails closed", !RuntimeGate.validateDescriptor(BridgeDescriptor(true, job.origin, 1, false), job.origin).pass)

    println("RESULT pass=$pass fail=$fail")
    if (fail != 0) error("TEST_FAILURE")
}
