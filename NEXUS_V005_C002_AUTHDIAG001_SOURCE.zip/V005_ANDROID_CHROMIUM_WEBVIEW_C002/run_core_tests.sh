#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/.core-test-out"
rm -rf "$OUT" && mkdir -p "$OUT"
kotlinc \
  "$ROOT/app/src/main/java/nexus/android/c002/core/TransportContract.kt" \
  "$ROOT/app/src/main/java/nexus/android/c002/core/AuthFlowDiagnostics.kt" \
  "$ROOT/core-tests/TestMain.kt" \
  -include-runtime -d "$OUT/tests.jar"
java -jar "$OUT/tests.jar"
