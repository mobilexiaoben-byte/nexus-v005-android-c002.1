#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PASS=0
FAIL=0
check() {
  local id="$1"; shift
  if "$@"; then echo "PASS $id"; PASS=$((PASS+1)); else echo "FAIL $id"; FAIL=$((FAIL+1)); fi
}
check_text() { grep -Fq "$2" "$1"; }

check T01_profile_declared check_text "$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt" 'WebViewCompat.setProfile(webView, PROFILE_NAME)'
check T02_origin_restricted_isolated_bridge check_text "$ROOT/app/src/main/java/nexus/android/c002/web/NexusWebBridge.kt" 'JS_INJECTION_IN_FRAME_AND_WORLD'
check T02_no_addJavascriptInterface bash -c "! grep -R -Fq 'addJavascriptInterface' '$ROOT/app/src/main/java' '$ROOT/app/src/main/assets/nexus/chatgpt_provider_c002.js' '$ROOT/app/src/main/assets/nexus/claude_provider_c002.js'"
check T02_no_chrome_runtime_refs bash -c "! grep -Fq 'chrome.runtime' '$ROOT/app/src/main/assets/nexus/chatgpt_provider_c002.js' '$ROOT/app/src/main/assets/nexus/claude_provider_c002.js'"
check T02_adapter_sources_present test -s "$ROOT/app/src/main/assets/nexus/chatgpt_provider_c002.js"
check T02_adapter_sources_present_claude test -s "$ROOT/app/src/main/assets/nexus/claude_provider_c002.js"
check T25_no_live_surface_files bash -c "! find '$ROOT' -type f | grep -E '(Guest|MAIN).*live'"
check T03_describe_contract check_text "$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt" 'NEXUS_ANDROID_DESCRIBE_C002'
check T03_describe_stop_gate check_text "$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt" 'DESCRIBE PASS — STOP GATE'
check T03_no_execute_job_native bash -c "! grep -Fq '"EXECUTE_JOB"' '$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt'"
node --check "$ROOT/app/src/main/assets/nexus/chatgpt_provider_c002.js"
node --check "$ROOT/app/src/main/assets/nexus/claude_provider_c002.js"
"$ROOT/run_core_tests.sh"
check AUTH04_sanitized_url_display check_text "$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt" 'AuthFlowSanitizer.sanitizeLocation(url)'
check AUTH05_navigation_events check_text "$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt" 'NAV_REQUEST'
check AUTH06_http_error_events check_text "$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt" 'MAIN_FRAME_HTTP'
check AUTH07_ssl_fail_closed check_text "$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt" 'handler.cancel()'
check AUTH08_bridge_origin_unchanged bash -c "grep -Fq 'setOf(\"https://chatgpt.com\")' '$ROOT/app/src/main/java/nexus/android/c002/web/NexusWebBridge.kt'"
check AUTH09_no_cookie_api bash -c "! grep -R -E 'CookieManager|document\.cookie|Authorization:' '$ROOT/app/src/main/java/nexus/android/c002'"
echo "STATIC_RESULT pass=$PASS fail=$FAIL"
test "$FAIL" -eq 0
